from gendiff.generate_gendiff import generate_diff

__all__ = ['generate_diff']
